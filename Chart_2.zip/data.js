var data = {
    "Event":{
      
      "data":[
      {
        "startDate":"2021-04-08 07:20",
        "endDate": "2021-04-08 09:20",
        "tool": 1,
        "status":"LOST"
      }
    ]
    },
    "Event5":{
      
        "data":[
        {
          "startDate":"2021-04-08 09:20",
          "endDate": "2021-04-09 07:20",
          "tool": 1,
          "status":"UP"
        }
      ]
      }
      ,
    "Event2":{
      
      "data":[
      {
        "startDate":"2021-04-08 07:20",
        "endDate": "2021-04-08 08:20",
      "tool": 2,
      "status":"UP"
      }
    ]
    },
    "Event3":{
      
      "data":[
      {
        "startDate":"2021-04-08 08:20",
        "endDate": "2021-04-09 07:20",
      "tool": 2,
      "status":"UP"
      }
    ]
    },
    "Event4":{

      "data":[
      {
        "startDate":"2021-04-08 07:20",
        "endDate": "2021-04-09 07:20",
        "tool": 0, 
        "status":"UP"
      }
    ]
    } 
    
  
  };