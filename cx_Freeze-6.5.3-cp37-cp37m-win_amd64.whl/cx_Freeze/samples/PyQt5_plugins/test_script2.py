print("bye")
