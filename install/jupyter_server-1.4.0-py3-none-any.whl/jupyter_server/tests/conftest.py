pytest_plugins = [
    "jupyter_server.pytest_plugin"
]
