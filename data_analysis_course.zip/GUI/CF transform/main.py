import wx
import form


class my_frame(form.MyFrame1):
    def __init__(self,parent):
        self.tran = True
        self.n1, self.n2 = 0,0
        form.MyFrame1.__init__(self,parent)
    def edit1(self,parent):
        self.tran = True
        

    def edit2(self,parent):
        self.tran = False
        

    def transform(self,parent):
        if self.tran:
            self.n1 = float(self.m_textCtrl5.GetValue())
            self.n2 =9./5.*self.n1+32
            self.m_textCtrl6.SetValue(str(self.n2))
        else:
            self.n2 = float(self.m_textCtrl6.GetValue())
            self.n1 = (self.n2-32)*5./9.
            self.m_textCtrl5.SetValue(str(self.n1))
    


class App(wx.App):
    def OnInit(self):
        self.m_frame = my_frame(None)
        self.m_frame.Show()
        return True

if __name__ == '__main__':
    app = App()
    app.MainLoop()
