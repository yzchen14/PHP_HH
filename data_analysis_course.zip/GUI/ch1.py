import wx


# create a class inherit wx.App
class my_App(wx.App):
    def OnInit(self):
        frame = wx.Frame(parent=None, title='Hello')
        frame.Show()
        return True


def main():
    app = my_App(None)
    app.MainLoop()

if __name__ == '__main__':
    main()