import numpy as np
import matplotlib.pyplot as plt
a = 1000.

x = np.linspace(0, 100, 5000)
y = 6 * x
plt.plot(x, y, 'x')
plt.show()
