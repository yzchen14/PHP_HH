fig = figure
plotyy(Y,C,Y,T)
