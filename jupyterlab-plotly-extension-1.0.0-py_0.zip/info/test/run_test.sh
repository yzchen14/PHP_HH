

set -ex



jupyter labextension list
jupyter lab build
exit 0
